1. Install the Matlab Component Libraray bu launching MCRInstaller.exe
2. Run matlab_1.03.exe

